extends "res://scripts/world_obsidian_tower_playback.gd"
## Normal earned Bride victory -> physical cable descent -> crown causeway.
const CROWN_ENTRY_SAVE := "user://test_world_c06_earned_entry.json"
var crown_elite_engaged:=false
var crown_flying_target:=""
const CROWN_ENTRY_SEED := "res://../artifacts/t04_bride_retry/earned_bride_seed.json"
func _run() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--crown-entry-proof="):
            var proof: Variant=JSON.parse_string(arg.trim_prefix("--crown-entry-proof="))
            if not proof is Dictionary:_check(false,"crown proof must be dictionary");quit(1);return
            await _verify_crown_entry(proof)
            return
    for suffix in ["", ".bak", ".tmp"]:
        if FileAccess.file_exists(CROWN_ENTRY_SAVE+suffix):DirAccess.remove_absolute(ProjectSettings.globalize_path(CROWN_ENTRY_SAVE+suffix))
    var file:=FileAccess.open(CROWN_ENTRY_SAVE,FileAccess.WRITE)
    file.store_buffer(FileAccess.get_file_as_bytes(CROWN_ENTRY_SEED))
    file.close()
    scene=load("res://scenes/World.tscn").instantiate()
    scene.world_resume=true
    scene.world_save_path=CROWN_ENTRY_SAVE
    root.add_child(scene)
    await preload("res://scripts/world_ready_validation_helper.gd").wait_for(scene)
    current_scene=scene
    await _tick(15)
    _check(scene.currency_count==435 and scene.demo_complete and scene.inventory_counts.get("thread_dash",0)==0,"earned full Bride victory restores without unearned dash")
    _check(scene.inventory_counts.get("crown_resonance",0)==0,"immutable Bride seed begins without crown resonance")
    var route: Array=[
        ["leap",4490,656,20,"physical mirror threshold after actual victory"],
        ["fight"],
        ["walk",4560,656],
        ["leap",4790,700,999,"ordinary jump through defeated Bride gate"],
        ["walk",5315,700],
        ["leap",5550,850,999,"ordinary jump onto first cable landing"],
        ["walk",5780,1140],
        ["walk",5580,1440],
        ["walk",5810,1745],
        ["walk",5600,2050],
        ["walk",5820,2355],
        ["walk",5610,2650],
        ["cable_fight"],
        ["walk",5730,2650],
        ["leap",6000,2724,20,"normal cable base to silent gate approach"],
        ["walk",6110,2724],
        ["leap",6330,2680,999,"ordinary jump to silent gate step"],
        ["leap",6650,2722,20,"actual exit dock"],
    ]
    for action in route:
        var ok:=true
        if action[0]=="cable_fight":
            ok=await _clear_cable_censor()
            if ok:await _settled_recover()
        elif action[0]=="leap":ok=await _leap(Vector2(action[1],action[2]),action[3],action[4])
        elif action[0]=="walk":ok=await _walk_without_jump(Vector2(action[1],action[2]))
        else:ok=await _clear_nearby()
        if not ok:await _finish();return
    await _crown_exit()
    if failures==0:await _crown_lower_loop()
    await _finish()
func _crown_exit() -> void:
    steps+=1
    await _world_interact()
    if scene.world_passage.active:
        _axis(signf(scene.world_passage.destination_point.x-scene.world_passage.source_point.x))
        for frame in 3600:
            await _tick()
            if not scene.world_passage.active:break
        _release()
    for frame in 2000:
        if not _transition_busy():break
        await process_frame
    await _tick(15)
    _check(String(scene.config.id)=="demo_ch06_silent_crown_core","actual crown causeway enters C6")
    print("CROWN_ENTRY_STATE ",JSON.stringify({"position":str(scene.player.position),"wallet":scene.currency_count,"inventory":scene.inventory_counts,"checkpoint":scene.active_save_point_id}))
func _finish() -> void:
    _release()
    Input.action_release("skill_1")
    _check(deaths==0,"actual crown entry survives without death")
    print("WORLD_C06_ENTRY steps=%d failures=%d deaths=%d damage_suppression=false"%[steps,failures,deaths])
    if failures==0:
        var original: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(CROWN_ENTRY_SEED))
        var inventory: Dictionary=original.inventory_counts.duplicate(true)
        inventory.obsidian_splinter+=2
        inventory.crown_resonance=1
        inventory.crown_echo_shard=scene.enemy_defeated+2+5
        _check(scene.story_flags.get("elite_first_demo_ch06_silent_crown_core_E01",false),"actual rain elite first-clear flag supplies its one-time reward")
        _check(scene.currency_count==int(original.currency)+16+scene.enemy_defeated*8+30 and _exact_state(scene.inventory_counts,inventory),"actual production defeat count, elite first reward and vault pickup give exact earned income")
        print("CROWN_INCOME ",JSON.stringify({"c5_normal_defeats":2,"c6_normal_defeats":scene.enemy_defeated,"elite_currency":30,"elite_material":2,"vault_material":5,"wallet":scene.currency_count}))
        _check(_exact_state(scene.build_system.serialize(),original.build_state),"normal crown route preserves every exact build and tool count")
    if failures==0:
        print("CROWN_ENTRY_PROOF ",JSON.stringify(_crown_entry_proof()))
        print("CROWN_ENTRY_EARNED_SEED ",ProjectSettings.globalize_path(CROWN_ENTRY_SAVE))
    print("CROWN_ENTRY_COST ",JSON.stringify({"damage":damage_events,"heals":heals,"frames":frames}))
    preload("res://scripts/audio_retirement.gd").retire_tree(scene)
    scene.queue_free()
    for unused in 10:await process_frame
    preload("res://scripts/audio_director.gd")._stream_cache.clear()
    preload("res://scripts/audio_director.gd")._npc_voice_cache.clear()
    _check(await preload("res://scripts/audio_retirement.gd").drain(self),"crown entry fixture retires audio")
    quit(0 if failures==0 else 1)

func _near_foe() -> Node2D:
    if crown_elite_engaged or not crown_flying_target.is_empty():return null
    if is_instance_valid(scene) and is_instance_valid(scene.player) and String(scene.config.id)=="demo_ch06_silent_crown_core" and scene.player.position.y>1600:
        for foe in get_nodes_in_group("enemy"):
            if is_instance_valid(foe) and foe.spawn_id=="E05" and foe.hp>0 and absf(foe.position.x-scene.player.position.x)<250 and absf(foe.position.y-scene.player.position.y)<240:return foe
    if is_instance_valid(scene) and is_instance_valid(scene.player) and String(scene.config.id)=="demo_ch05_obsidian_pilgrim_road" and scene.player.position.y>2300:
        for foe in get_nodes_in_group("enemy"):
            if is_instance_valid(foe) and foe.spawn_id=="E14" and foe.hp>0 and absf(foe.position.x-scene.player.position.x)<250 and absf(foe.position.y-scene.player.position.y)<240:return foe
    return super._near_foe()
func _clear_cable_censor() -> bool:
    steps+=1
    _release()
    var jumped_at: int=-100
    combat_enabled=true
    for frame in 600:
        var foe:=_near_foe()
        if foe==null:
            _release()
            combat_enabled=false
            return true
        var p: CharacterBody2D=scene.player
        var dx: float=foe.position.x-p.position.x
        _axis(signf(dx) if absf(dx)>90 or p.facing!=signi(dx) else 0)
        if frame-jumped_at>=25:Input.action_release("jump")
        if foe.position.y<p.position.y-90 and p.is_on_floor() and p.hurt_timer<=0 and p.attack_timer<=0 and frame-jumped_at>50:
            Input.action_press("jump");jumped_at=frame;await process_frame
        await _tick()
        if deaths>0:break
    combat_enabled=false
    _release()
    _check(false,"actual cable censor normal air attacks finish")
    return false

func _crown_lower_loop() -> void:
    if not await _heart_interact("npc_first_pilgrim_echo",3050):return
    _check(scene.active_overlay=="dialogue","actual first pilgrim dialogue opens")
    _check(scene.inventory_counts.get("crown_resonance",0)==1 and scene.world_collected_ids.get("upgrade_obtain_crown_resonance",false),"normal forecourt body pickup persists through the following NPC conversation")
    Input.action_press("close_overlay");await _tick(3);Input.action_release("close_overlay");await _tick(3)
    var route: Array=[
        ["walk",3135,700],
        ["leap",3380,748,999,"normal east crown shoulder"],
        ["leap",3660,836,999,"first bone span before clapper"],
        ["leap",4000,940,20,"real jump over shell clapper"],
        ["leap",4290,1052,999,"third east shoulder bone"],
        ["leap",4660,1180,35,"real jump past false moss rain floor"],
        ["elite_fight"],
        ["walk",4820,1180],
        ["leap",5150,1128,20,"normal rain wheel stand"],
        ["fight"],
        ["walk",4960,1300],
        ["walk",4760,1452],
        ["fight"],
        ["walk",4680,1452],
        ["leap",4400,1580,35,"normal string echo shelf beyond chest"],
        ["fight"],
        ["leap",4130,1712,20,"string outward shelf"],
        ["leap",3850,1810,20,"normal eastern ring"],
        ["flyer","E05"],
        ["walk",3730,1810],
        ["leap",3450,1876,20,"eastern ring scribe platform"],
        ["flyer","E06"],
        ["walk",3355,1876],
        ["leap",3130,1930,20,"real jump beyond ring bell gap"],
        ["walk",2850,2080],
        ["walk",3010,2360],
        ["walk",2850,2640],
        ["walk",2700,2900],
    ]
    for action in route:
        var ok:=true
        if action[0]=="flyer":ok=await _clear_crown_flyer(action[1])
        elif action[0]=="elite_fight":ok=await _clear_rain_elite()
        elif action[0]=="leap":ok=await _leap(Vector2(action[1],action[2]),action[3],action[4])
        elif action[0]=="walk":ok=await _walk_without_jump(Vector2(action[1],action[2]))
        else:
            ok=await _clear_nearby()
            if ok:await _settled_recover()
        if not ok:return
    if not await _heart_interact("ch06_silent_crown_core_shortcut_lever",2830):return
    if not await _heart_interact("save_ch06_lower_loop",2570):return
    _check(scene.active_save_point_id=="save_ch06_lower_loop" and scene.player.hp==scene.player.max_hp and scene.player.energy==scene.player.max_energy,"normal first crown lower-loop shrine rest")
    _check(not scene.boss_spawned and not is_instance_valid(scene.boss_arena_lock_body) and not scene.audio_director.boss_active,"actual lower-loop lever never starts a remote crown Boss or music")
    _check(scene.world_collected_ids.get("col_branch_bell_tongue_vault",false),"actual vault crossing collects its five authored crown fragments")
    _check(not JOURNAL.owned(scene.story_flags,String(scene.config.id)),"crown route does not invent the still-unmet deep map seller purchase")
    print("CROWN_LOWER_REST ",JSON.stringify({"wallet":scene.currency_count,"inventory":scene.inventory_counts,"checkpoint":scene.active_save_point_id,"shortcuts":scene.opened_shortcuts,"boss_unlocked":scene.boss_unlocked,"boss_defeated":scene.demo_complete}))

func _clear_rain_elite() -> bool:
    steps+=1
    crown_elite_engaged=true
    tower_spear=false
    combat_enabled=false
    _release()
    var jumped_at: int=-1000
    var doubled:=false
    var jump_kind:=""
    for frame in 1200:
        var foe: Node2D=null
        for actor in get_nodes_in_group("enemy"):
            if is_instance_valid(actor) and actor.spawn_id=="E01" and actor.hp>0:foe=actor;break
        if foe==null:
            crown_elite_engaged=false;_release();await _settled_recover();return true
        var p: CharacterBody2D=scene.player
        var state: String=String(foe.state)
        var kind: String=String(foe.active_attack.get("type",""))
        var side: float=signf(p.position.x-foe.position.x)
        if side==0:side=-1
        var punish: bool=state=="recover" or (state=="windup" and kind!="guard" and foe.state_timer>0.6)
        var goal: float=clampf(foe.position.x+side*(110 if punish else 195),4635,4855)
        _axis(signf(goal-p.position.x) if absf(goal-p.position.x)>7 else 0)
        if state=="windup" and foe.state_timer<0.25 and p.is_on_floor() and p.attack_timer<=0 and p.hurt_timer<=0 and (kind in ["wave","projectile"] or (kind=="guard" and p.energy<8)):
            Input.action_press("jump");jumped_at=frame;doubled=false;jump_kind=kind;await process_frame
        if frame-jumped_at==30:Input.action_release("jump");await process_frame
        if frame-jumped_at>=40 and frame-jumped_at<60 and jump_kind in ["wave","projectile"] and not doubled and p.air_jump_available and p.attack_timer<=0 and p.hurt_timer<=0:
            Input.action_press("jump");doubled=true;await process_frame
        if frame-jumped_at==75:Input.action_release("jump")
        if state=="windup" and kind=="guard" and foe.state_timer<0.14 and p.guard_cooldown<=0 and p.attack_timer<=0 and p.hurt_timer<=0 and p.energy>=8:
            _axis(signf(foe.position.x-p.position.x))
            Input.action_press("bell_guard");await process_frame;await _tick(2);Input.action_release("bell_guard")
        var dx: float=foe.position.x-p.position.x
        if punish and p.is_on_floor() and absf(dx)<140 and p.attack_timer<=0 and p.hurt_timer<=0:
            _axis(signf(dx))
            if p.skill_cooldown<=0 and p.energy>=25:
                Input.action_press("skill_1");tower_skill_at=frames;await process_frame
            elif not Input.is_action_pressed("attack"):
                Input.action_press("attack");attack_pressed_frame=frames
        for effect in get_nodes_in_group("hostile_attack"):
            if not is_instance_valid(effect) or effect.owner_actor!=foe or effect.hit_player:continue
            if effect.position.distance_to(p.position-Vector2(0,42))<95 and p.guard_cooldown<=0 and p.attack_timer<=0 and p.hurt_timer<=0 and p.energy>=8:
                _axis(signf(effect.position.x-p.position.x))
                Input.action_press("bell_guard");await process_frame;await _tick(2);Input.action_release("bell_guard")
        if frame%30==0:print("CROWN_ELITE ",JSON.stringify({"player":str(p.position),"hp":p.hp,"energy":p.energy,"foe_hp":foe.hp,"foe_position":str(foe.position),"state":state,"kind":kind,"remaining":foe.state_timer}))
        await _tick()
        if p.hp<=0:break
    crown_elite_engaged=false;_release();Input.action_release("skill_1")
    _check(false,"normal earned cleave punishes actual rain elite recovery")
    return false

func _settled_recover() -> void:
    _release()
    for frame in 90:
        if scene.player.attack_timer<=0 and scene.player.hurt_timer<=0 and scene.player.is_on_floor():break
        await _tick()
    if scene.player.hp>0 and scene.player.hp<scene.player.max_hp and scene.player.energy>=scene.player.heal_energy_cost:await _recover()

func _leap(target: Vector2,second_frame: int,label: String) -> bool:
    _release()
    for frame in 120:
        if scene.player.is_on_floor() and scene.player.hurt_timer<=0 and scene.player.attack_timer<=0:break
        await _tick()
    print("CROWN_JUMP_START ",JSON.stringify({"label":label,"position":str(scene.player.position),"floor":scene.player.is_on_floor(),"hurt":scene.player.hurt_timer,"air_jump":scene.player.air_jump_available}))
    return await super._leap(target,second_frame,label)
func _clear_crown_flyer(spawn_id: String) -> bool:
    steps+=1
    _release()
    combat_enabled=false
    crown_flying_target=spawn_id
    var jumped_at: int=-1000
    var doubled:=false
    for frame in 900:
        var foe: Node2D=null
        for actor in get_nodes_in_group("enemy"):
            if is_instance_valid(actor) and actor.spawn_id==spawn_id and actor.hp>0:foe=actor;break
        if foe==null:
            crown_flying_target="";_release();await _settled_recover();print("CROWN_FLYER_DEFEATED ",spawn_id);return true
        var p: CharacterBody2D=scene.player
        var dx: float=foe.position.x-p.position.x
        _axis(signf(dx) if absf(dx)>80 or p.facing!=signi(dx) else 0)
        if foe.position.y<p.position.y-75 and p.is_on_floor() and p.hurt_timer<=0 and p.attack_timer<=0 and frame-jumped_at>80:
            Input.action_press("jump");jumped_at=frame;doubled=false;await process_frame
        if frame-jumped_at==17:Input.action_release("jump");await process_frame
        if frame-jumped_at>=20 and frame-jumped_at<40 and not doubled and p.air_jump_available and p.hurt_timer<=0 and p.attack_timer<=0:
            Input.action_press("jump");doubled=true;await process_frame
        if frame-jumped_at==55:Input.action_release("jump")
        var normal_floor_attack: bool=p.is_on_floor() and foe.position.y>=p.position.y-75
        if (normal_floor_attack or frame-jumped_at>=22) and absf(dx)<110 and absf(foe.position.y-p.position.y)<110 and p.hurt_timer<=0 and p.attack_timer<=0:
            _axis(signf(dx));Input.action_press("attack");attack_pressed_frame=frames
        await _tick()
        if p.hp<=0:break
    crown_flying_target="";_release();_check(false,"actual crown flyer "+spawn_id+" falls to existing normal double-jump attacks");return false

func _crown_entry_proof() -> Dictionary:
    var proof:=_tower_proof()
    proof.merge({"hp":scene.player.hp,"max_hp":scene.player.max_hp,"energy":scene.player.energy,"cache":scene.world_state.data.get("death_cache",{}).duplicate(true),"spawn":[scene.active_spawn.x,scene.active_spawn.y],"regions":scene.world_state.data.regions.duplicate(true),"owned":JOURNAL.owned(scene.story_flags,String(scene.config.id)),"pending":JOURNAL.region(scene.story_flags,String(scene.config.id)).pending.duplicate(true),"boss_unlocked":scene.boss_unlocked,"boss_defeated":scene.demo_complete})
    return proof
func _verify_crown_entry(proof: Dictionary) -> void:
    scene=load("res://scenes/World.tscn").instantiate()
    scene.world_resume=true
    scene.world_save_path=CROWN_ENTRY_SAVE
    root.add_child(scene)
    await preload("res://scripts/world_ready_validation_helper.gd").wait_for(scene)
    current_scene=scene
    await _tick(15)
    var pid: Variant=proof.get("pid",0)
    _check(typeof(pid) in [TYPE_INT,TYPE_FLOAT] and pid>0 and pid==int(pid) and OS.get_process_id()!=int(pid),"crown checkpoint opens in a different actual process")
    var actual:=_crown_entry_proof()
    for key in ["region","checkpoint","wallet","inventory","build","story","charted","shortcuts","hp","max_hp","energy","cache","spawn","regions","owned","pending","boss_unlocked","boss_defeated"]:
        _check(proof.has(key) and _exact_state(actual[key],proof[key]),"crown restart retains exact "+key)
    _check(scene.active_save_point_id=="save_ch06_lower_loop" and scene.player.position.distance_to(Vector2(2570,2860))<90,"new process resumes at the actually rested lower-loop shrine")
    _check(not scene.boss_spawned and not is_instance_valid(scene.boss_arena_lock_body) and not scene.audio_director.boss_active,"unlocked crown Boss remains unentered after exact restart")
    _check(scene.inventory_counts.get("thread_dash",0)==0,"normal crown arrival never grants dash")
    print("WORLD_C06_ENTRY_RESTART failures=%d pid_changed=true"%failures)
    _release()
    preload("res://scripts/audio_retirement.gd").retire_tree(scene)
    scene.queue_free()
    for unused in 10:await process_frame
    preload("res://scripts/audio_director.gd")._stream_cache.clear()
    preload("res://scripts/audio_director.gd")._npc_voice_cache.clear()
    _check(await preload("res://scripts/audio_retirement.gd").drain(self),"crown restart fixture retires audio")
    quit(0 if failures==0 else 1)

func _world_interact() -> void:
    var target: Area2D=scene.interaction_target()
    if String(scene.config.id)=="demo_ch06_silent_crown_core" and target!=null and String(target.name)=="npc_first_pilgrim_echo":
        _check(scene.world_collected_ids.get("upgrade_obtain_crown_resonance",false) and scene.inventory_counts.get("crown_resonance",0)==1,"normal body-enter pickup is already earned before the first NPC F input")
        print("CROWN_RESONANCE_BEFORE_F ",JSON.stringify({"frame":frames,"position":str(scene.player.position),"collected_id":"upgrade_obtain_crown_resonance","count":scene.inventory_counts.get("crown_resonance",0),"overlay":String(scene.active_overlay)}))
    await super._world_interact()
