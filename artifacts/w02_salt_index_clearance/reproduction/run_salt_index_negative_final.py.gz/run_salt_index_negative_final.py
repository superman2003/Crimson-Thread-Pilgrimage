from pathlib import Path
import subprocess,json,hashlib
p=Path('godot/data/demo_ch03_saltwhite_archive.json');fixed=p.read_bytes();old=Path('output/salt_index_old_ch03.json').read_bytes();assert json.loads(old)['id']==json.loads(fixed)['id']
try:
 p.write_bytes(old)
 result=subprocess.run(['python','output/run_salt_index_suites.py','negative_old_final','salt_archive_experience']).returncode
finally:
 p.write_bytes(fixed)
folder=Path('artifacts/w02_salt_index_clearance/negative_old_final');v=json.loads((folder/'verification.json').read_text(encoding='utf-8'));assert result==1 and len(v['results'][0]['engine_errors'])==1 and v['source_unchanged'];assert p.read_bytes()==fixed
(folder/'restoration.json').write_text(json.dumps(dict(scope='Only restore original 32px shelf data for the final ordinary-jump fixture; return to exact 24px shelf bytes afterwards',old_sha256=hashlib.sha256(old).hexdigest(),fixed_sha256=hashlib.sha256(fixed).hexdigest(),restored_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),restored_exact=p.read_bytes()==fixed,expected_runner_exit=result),indent=2)+'\n',encoding='utf-8')
print('Expected old-shelf failure and exact restoration verified',flush=True)
