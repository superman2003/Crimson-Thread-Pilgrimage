from pathlib import Path
import subprocess,sys,os,json,gzip,re,time,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'tools'));from run_damage_route import freeze
folder=root/'artifacts/w02_salt_index_clearance'/sys.argv[1];folder.mkdir(parents=True,exist_ok=True)
script='output/t04_salt_index_fixture.gd'
def sources():
 result=freeze()
 for name in [script,'output/run_salt_index_fixture.py']:result[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
 return result
before=sources();code=None;timeout=False;start=time.monotonic();cmd=[str(Path(os.environ['TEMP'])/'ctp-godot-4.6.1/Godot_v4.6.1-stable_win64.exe'),'--position','-32000,-32000','--audio-driver','Dummy','--rendering-method','gl_compatibility','--fixed-fps','60','--path',str(root/'godot'),'--script',str(root/script)]
with (folder/'runtime.log').open('w',encoding='utf-8') as output:
 try:code=subprocess.run(cmd,stdout=output,stderr=subprocess.STDOUT,env=dict(os.environ,SALT_FIXTURE_DIR=str(folder)),timeout=180).returncode
 except subprocess.TimeoutExpired:timeout=True
after=sources();plain=(folder/'runtime.log').read_text(encoding='utf-8');errors=re.findall(r'^\s*(?:SCRIPT ERROR:|ERROR:).*$',plain,re.M);marker=re.search(r'^SALT_INDEX_FIXTURE failures=0 positioned=true actors_paused=true$',plain,re.M)
for name,values in [('before',before),('after',after)]:(folder/('source-'+name+'.json.gz')).write_bytes(gzip.compress((json.dumps(values,indent=2)+'\n').encode(),mtime=0))
(folder/'script.gd.txt').write_bytes((root/script).read_bytes());(folder/'source.diff').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','HEAD','--','godot'],cwd=root))
v=dict(scope='Positioned production World single-jump geometry fixture; actors paused, no extra abilities; not route acceptance',head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),command=cmd,seconds=round(time.monotonic()-start,2),timeout_seconds=180,exit=code,timed_out=timeout,engine_errors=errors,objectdb_warnings=plain.count('ObjectDB instances leaked'),source_files=len(before),source_unchanged=before==after,completion=marker.group(0) if marker else None,passed=code==0 and not timeout and not errors and bool(marker) and before==after);(folder/'verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2));raise SystemExit(0 if v['passed'] else 1)
