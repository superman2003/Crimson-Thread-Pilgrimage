from pathlib import Path
import json,subprocess,os,sys,re,gzip,copy,time,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'tools'));from run_archive_lower import sources
folder=root/'artifacts/w02_salt_index_clearance/restart_checks';folder.mkdir(parents=True,exist_ok=True)
engine=Path(os.environ['TEMP'])/'ctp-godot-4.6.1/Godot_v4.6.1-stable_win64.exe';proof=json.loads((root/'artifacts/w02_salt_index_clearance/final_natural_01/restart-proof.json').read_text(encoding='utf-8'))
cases=[]
for name in ['correct','wrong_wallet','fractional_count','missing_pid','missing_note','wrong_checkpoint']:
 expected=copy.deepcopy(proof)
 if name=='wrong_wallet':expected['wallet']+=1
 if name=='fractional_count':expected['inventory']['wet_chitin']+=.5
 if name=='missing_pid':del expected['pid']
 if name=='missing_note':del expected['charted'][next(iter(expected['charted']))]
 if name=='wrong_checkpoint':expected['checkpoint']='save_ch03_lower_loop'
 cases.append((name,expected))
before=sources();results=[]
for name,expected in cases:
 cmd=[str(engine),'--position','-32000,-32000','--audio-driver','Dummy','--rendering-method','gl_compatibility','--fixed-fps','60','--path',str(root/'godot'),'--script','res://scripts/world_archive_lower_playback.gd','--','--archive-lower-restart-proof='+json.dumps(expected,separators=(',',':'))]
 start=time.monotonic();timeout=False;code=None
 with (folder/(name+'.log')).open('w',encoding='utf-8') as output:
  try:code=subprocess.run(cmd,stdout=output,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired:timeout=True
 plain=(folder/(name+'.log')).read_text(encoding='utf-8');errors=re.findall(r'^\s*(?:SCRIPT ERROR:|ERROR:).*$',plain,re.M)
 ok=(code==0 and not errors and 'WORLD_ARCHIVE_LOWER_RESTART failures=0 pid_changed=true' in plain) if name=='correct' else (code==1 and len(errors)==1 and 'WORLD_ARCHIVE_LOWER_RESTART failures=1 pid_changed=true' in plain)
 item=dict(case=name,command=cmd,seconds=round(time.monotonic()-start,2),exit=code,timed_out=timeout,errors=errors,objectdb_warnings=plain.count('ObjectDB instances leaked'),passed=ok and not timeout);results.append(item);print(name,item['passed'],code,errors,flush=True)
after=sources()
for label,state in [('before',before),('after',after)]:(folder/('source-'+label+'.json.gz')).write_bytes(gzip.compress((json.dumps(state,indent=2)+'\n').encode(),mtime=0))
(folder/'verification.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_files=len(before),source_unchanged=before==after,results=results),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if before==after and all(r['passed'] for r in results) else 1)
