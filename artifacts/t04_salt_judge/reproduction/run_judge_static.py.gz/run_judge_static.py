from pathlib import Path
import subprocess,json,datetime,time,sys
out=Path('artifacts/t04_salt_judge')/sys.argv[1];out.mkdir(exist_ok=True);results=[]
for name,args in [('npm_test',['npm.cmd','test']),('campaign',['npm.cmd','run','test:campaign']),('pycompile',[sys.executable,'-m','py_compile','tools/run_judge_route.py'])]:
 start=time.monotonic()
 with (out/(name+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 item=dict(check=name,command=args,seconds=round(time.monotonic()-start,2),exit=p.returncode);results.append(item);print(item,flush=True)
(out/'verification.json').write_text(json.dumps(dict(date=datetime.datetime.now().astimezone().isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),results=results),indent=2)+'\n',encoding='utf-8');sys.exit(0 if all(r['exit']==0 for r in results) else 1)
